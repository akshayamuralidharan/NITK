s=raw_input()
r=s[::-1]

for i in range(len(r)):
    if r[i]=='A':
        r=r[0:i]+'T'+r[i+1:]
    elif r[i]=='C':
        r=r[0:i]+'G'+r[i+1:]
    elif r[i]=='G':
        r=r[0:i]+'C'+r[i+1:]
    elif r[i]=='T':
        r=r[0:i]+'A'+r[i+1:]

print r


    


