s=raw_input()

print s.count('A'),s.count('C'),s.count('G'),s.count('T')
