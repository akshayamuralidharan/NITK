a=map(lambda x:int(x),raw_input().split(' '))

if a[0]%2==1:
    i=a[0]
else:
    i=a[0]+1

sum=0

while i<=a[1]:
    sum=sum+i
    i=i+2
print sum
