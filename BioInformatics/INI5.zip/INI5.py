f=open("ip","r")
l=f.read().split('\n')
#print l

i=0
while l[i]:
    if i%2==1:
        print l[i]
    i=i+1
    
