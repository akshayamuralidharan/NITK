a=raw_input()
b=raw_input().split(' ')
b=map(lambda x: int(x),b)
c=a[b[0]:b[1]+1]
print  c , a[b[2]:b[3]+1] 
