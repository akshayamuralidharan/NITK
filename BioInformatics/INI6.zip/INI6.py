a=raw_input().split(' ')

i=0
d={}

while i<len(a):
    if a[i] in d:
        d[a[i]]=d[a[i]]+1
    else:
        d[a[i]]=1
    i=i+1

for ele in d:
    print ele, d[ele]
