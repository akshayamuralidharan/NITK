s=raw_input().split(' ')
n=int(s[0])
k=int(s[1])
l=[1,1]
i=2
while i<n:
   l.append(l[i-1]+l[i-2]*k)
   i=i+1
    

print l[-1]


    


