s=raw_input()
r=s.replace('T','U')
print r
